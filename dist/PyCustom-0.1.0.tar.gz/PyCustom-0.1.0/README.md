# PyCustom
Offering functionalities that are not yet available.<br><br>
_**Consider Starring the Repo, if you find it useful**_ <br>

## Predictive Power Score _(currently working on this)_
A score that helps identifying linear and non-linear relations between features/attributes.

I was unable to find the option to explicitly mention categorical and numerical features in one of the libraries offering ppscore, which was leading to regression in case of categorical attribute. PyCustom.pps will rectify this issue (At Least that is the vision currently).
